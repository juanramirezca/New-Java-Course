public class LoopsMain {
    public static void main(String[] args) {
        System.out.println("They are here!!!");
    }
}
